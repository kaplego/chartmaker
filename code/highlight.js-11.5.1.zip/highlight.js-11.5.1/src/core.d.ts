import hljs from "highlight.js";
export default hljs;

